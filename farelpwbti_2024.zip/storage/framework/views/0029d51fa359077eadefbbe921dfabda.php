

<?php $__env->startSection('title', 'Data Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-center"> Data Mahasiswa</h1>
    <div class="row">
        <a href="<?php echo e(route('mahasiswa.tambah')); ?>" class="btn btn-success">Tambah Data</a>
    
        <table class="table">
        <thead>
      </div>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Name</th>
      <th scope="col">NIM</th>
      <th scope="col">Program Studi</th>
      <th scope="col">Email</th>
      <th scope="col">no. Hp</th>
      <th scope="col">AKSI</th>
    </tr>
  </thead>
  <tbody>
    <?php $i=1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th scope="row"><?php echo $i?></th>
        <td><?php echo e($mahasiswa["name"]); ?></td>
        <td><?php echo e($mahasiswa["nim"]); ?></td>
        <td><?php echo e($mahasiswa["prodi"]); ?></td>
        <td><?php echo e($mahasiswa["email"]); ?></td>
        <td><?php echo e($mahasiswa["nohp"]); ?></td>
        <td>
            <button type="button" class="btn btn-primary">EDIT</button>
            <button type="button" class="btn btn-danger">HAPUS</button>
        </td>
        <?php $i++?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\FarelTI\farelpwbti_2024\resources\views/mahasiswa.blade.php ENDPATH**/ ?>