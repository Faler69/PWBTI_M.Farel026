@extends('layouts.main')

@section('content')
<h1>wok</h1>

@endsection